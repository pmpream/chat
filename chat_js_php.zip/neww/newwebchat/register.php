<?php
$servername = "localhost"; // เปลี่ยนเป็นชื่อเซิร์ฟเวอร์ MySQL ของคุณ
$username = "root"; // เปลี่ยนเป็นชื่อผู้ใช้ MySQL ของคุณ
$password = ""; // เปลี่ยนเป็นรหัสผ่าน MySQL ของคุณ
$dbname = "db_chat"; // เปลี่ยนเป็นชื่อฐานข้อมูลที่คุณต้องการใช้

$conn = mysqli_connect($servername,$username,$password,$dbname);


if(!$conn){
die("Connected". mysqli_connect_error());

}
//echo "Connected successfully";

?>

<!doctype html>
<html lang="en">
  <head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registion</title>
  <link rel="stylesheet" href="style.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">




    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>register</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
        <br>
        <div class="container">

<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
            <div class="col-lg-7">
                <div class="p-5">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                    </div>



        <div class="alert alert-primary h4" role="alert">
        กรอกข้อมูล
        </div>


        <br>
        <form method="POST" action="insert_register.php">
        ชื่อ <input type="text" name="firstname" class="form-control" required >
        นามสกุล <input type="text" name="lastname" class="form-control" required>
        Email <input type="text" name="email"  class="form-control" required>
        Password <input type="text" name="password"  maxlength="10" class="form-control" required>

        <br>
        <input type="submit" name="submit" value="บันทึก">
        <input type="reset" name="cancel" value="ยกเลิก"><br>


        <br>
        <a href="insert_register.php" class="btn btn-primary btn-user btn-block">
        Register Account
        </a>
        <hr>
        <a href="login.php" class="btn btn-primary btn-user btn-block">
        Login
        </a>
        <br>

        
        <br>
        <div class="two-col">
          <div class="one">
            <label><a href="login.php">คลิกที่นี่เพื่อเข้าสู่ระบบ</a></label>
          </div>
        </div>
                        


        

        </form>
    </div>

    </form>
                    <hr>
                   
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>


   
    



  </body>
</html>