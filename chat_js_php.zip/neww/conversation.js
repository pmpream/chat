function addConversationHistory(connection, intent, text, botResponse) {
  return new Promise((resolve, reject) => {
    const datetime = new Date();
    //เพิ่มข้อมูลเข้าฐานข้อมูล
    connection.query(
      'INSERT INTO conversation_history (intent, text, datetime, botResponse) VALUES (?, ?, ?, ?)',
      [intent, text, datetime, botResponse],
      (error, results, fields) => {
        let err = false;
        let message = null;
        if (error) {
          err = true;
          message = 'ไม่สามารถบันทึกข้อมูล';
          console.error('เกิดข้อผิดพลาดในการเพิ่มข้อมูล: ', error);
        } else {
          message = 'บันทึกข้อมูลเสร็จสิ้น';
          console.log(
            `${datetime}: Intent: ${intent}, Text: ${text}, botResponse: ${botResponse} => Inserted successfully`
          );
        }

        resolve({
          error: err,
          message: message,
          datetime: datetime,
        });
      }
    );
  });
}

module.exports = { addConversationHistory };
